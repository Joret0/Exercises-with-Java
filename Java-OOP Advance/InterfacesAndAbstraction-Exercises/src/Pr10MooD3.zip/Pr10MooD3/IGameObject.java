package Pr10MooD3;

public interface IGameObject {
    String getUserName();
    String getPassword();
    int getLevel();
    double getPoints();
}
