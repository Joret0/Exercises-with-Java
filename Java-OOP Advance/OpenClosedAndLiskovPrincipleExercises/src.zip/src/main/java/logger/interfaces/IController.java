package logger.interfaces;

public interface IController {
    void run();
}
