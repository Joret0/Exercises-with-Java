package logger.interfaces;

public interface IConsoleInputReader {
    String readLine();
}
