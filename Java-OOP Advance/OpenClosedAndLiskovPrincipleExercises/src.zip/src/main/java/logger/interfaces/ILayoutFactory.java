package logger.interfaces;

public interface ILayoutFactory {
    Layout getLayout(String type);
}
