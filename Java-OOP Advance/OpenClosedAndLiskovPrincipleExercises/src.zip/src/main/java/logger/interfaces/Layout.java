package logger.interfaces;

public interface Layout {
    String getFormat();
}
