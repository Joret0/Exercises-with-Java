package c_barracksWars.contracts;


public interface Attacker {
    int getAttackDamage();
}
