package c_barracksWars.contracts;

public interface Executable {
    String execute();
}
