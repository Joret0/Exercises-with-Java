package Pr9LinkedListTraversal.utilities;

public class Constants {
    public static final String JOINER = " ";
}
